package com.example.demoproject.data;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;

public class CanvasData implements Parcelable{
    private Uri bitmapIMG;
    private int frameHeight;
    private int frameWidth;
    private float scaleFactorX;
    private float scaleFactorY;
    private float imageX;
    private float imageY;
    private int frameID;
    private int stickerID;
    private float stickerX;
    private float stickerY;
    private String text;
    private float textX;
    private float textY;
    private int textFillID;
    private int textStrokeID;


    protected CanvasData(Parcel in) {

        bitmapIMG = in.readParcelable(Uri.class.getClassLoader());
        frameHeight = in.readInt();
        frameWidth = in.readInt();
        scaleFactorX=in.readFloat();
        scaleFactorY=in.readFloat();
        imageX = in.readFloat();
        imageY = in.readFloat();
        frameID = in.readInt();
        stickerID = in.readInt();
        stickerX = in.readFloat();
        stickerY = in.readFloat();
        text = in.readString();
        textX = in.readFloat();
        textY = in.readFloat();
        textFillID = in.readInt();
        textStrokeID = in.readInt();
    }
    public CanvasData(){

    }

    public static final Creator<CanvasData> CREATOR = new Creator<CanvasData>() {
        @Override
        public CanvasData createFromParcel(Parcel in) {
            return new CanvasData(in);
        }

        @Override
        public CanvasData[] newArray(int size) {
            return new CanvasData[size];
        }
    };

    public Uri getBitmapIMG() {
        return bitmapIMG;
    }

    public void setBitmapIMG(Uri bitmapIMG) {
        this.bitmapIMG = bitmapIMG;
    }

    public int getFrameHeight() {
        return frameHeight;
    }

    public void setFrameHeight(int frameHeight) {
        this.frameHeight = frameHeight;
    }

    public int getFrameWidth() {
        return frameWidth;
    }

    public void setFrameWidth(int frameWidth) {
        this.frameWidth = frameWidth;
    }
    public float getScaleFactorX() {
        return scaleFactorX;
    }

    public void setScaleFactorX(float scaleFactorX) {
        this.scaleFactorX = scaleFactorX;
    }

    public float getScaleFactorY() {
        return scaleFactorY;
    }

    public void setScaleFactorY(float scaleFactorY) {
        this.scaleFactorY = scaleFactorY;
    }

    public float getImageX() {
        return imageX;
    }

    public void setImageX(float imageX) {
        this.imageX = imageX;
    }

    public float getImageY() {
        return imageY;
    }

    public void setImageY(float imageY) {
        this.imageY = imageY;
    }

    public int getFrameID() {
        return frameID;
    }

    public void setFrameID(int frameID) {
        this.frameID = frameID;
    }

    public int getStickerID() {
        return stickerID;
    }

    public void setStickerID(int stickerID) {
        this.stickerID = stickerID;
    }

    public float getStickerX() {
        return stickerX;
    }

    public void setStickerX(float stickerX) {
        this.stickerX = stickerX;
    }

    public float getStickerY() {
        return stickerY;
    }

    public void setStickerY(float stickerY) {
        this.stickerY = stickerY;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public float getTextX() {
        return textX;
    }

    public void setTextX(float textX) {
        this.textX = textX;
    }

    public float getTextY() {
        return textY;
    }

    public void setTextY(float textY) {
        this.textY = textY;
    }

    public int getTextFillID() {
        return textFillID;
    }

    public void setTextFillID(int textFillID) {
        this.textFillID = textFillID;
    }

    public int getTextStrokeID() {
        return textStrokeID;
    }

    public void setTextStrokeID(int textStrokeID) {
        this.textStrokeID = textStrokeID;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(bitmapIMG,flags);
        dest.writeInt(frameHeight);
        dest.writeInt(frameWidth);
        dest.writeFloat(scaleFactorX);
        dest.writeFloat(scaleFactorY);
        dest.writeFloat(imageX);
        dest.writeFloat(imageY);
        dest.writeInt(frameID);
        dest.writeInt(stickerID);
        dest.writeFloat(stickerX);
        dest.writeFloat(stickerY);
        dest.writeString(text);
        dest.writeFloat(textX);
        dest.writeFloat(textY);
        dest.writeInt(textFillID);
        dest.writeInt(textStrokeID);
    }
}
