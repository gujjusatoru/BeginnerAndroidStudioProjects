package com.example.demoproject.activities;

import static android.provider.MediaStore.Images.Media.getBitmap;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.example.demoproject.R;
import com.example.demoproject.canvas.DrawImage;
import com.example.demoproject.data.CanvasData;

import java.io.IOException;

public class CanvasActivity extends AppCompatActivity {
    CanvasData dataSaved;
    DrawImage canvas;
    Button back, save;
    ImageView image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_canvas);

        Intent get= getIntent();
        dataSaved=new CanvasData();
        image=findViewById(R.id.image);
        dataSaved=get.getParcelableExtra("canvasData");
        Log.i("activity canvas", "text : "+dataSaved.getText());
        canvas=findViewById(R.id.canvasDraw);
        try {
            canvas.getData(dataSaved);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        try {
            int imgwidth=(int)(dataSaved.getFrameWidth()*dataSaved.getScaleFactorX());
            int imgheight=(int)(dataSaved.getFrameHeight()*dataSaved.getScaleFactorY());
            Bitmap bit=Bitmap.createScaledBitmap(getBitmap(getApplicationContext().getContentResolver(),dataSaved.getBitmapIMG()), imgwidth, imgheight, false);
            image.setImageBitmap(bit);
            image.setScaleX(dataSaved.getScaleFactorX());
            image.setScaleY(dataSaved.getScaleFactorY());

            image.setTranslationX(dataSaved.getImageX());
            image.setTranslationY(dataSaved.getImageY());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        back=findViewById(R.id.backbtn);
        save=findViewById(R.id.savebtn);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent saveIMG=new Intent(getApplicationContext(), SaveImage.class);
                startActivity(saveIMG);
            }
        });

    }
}