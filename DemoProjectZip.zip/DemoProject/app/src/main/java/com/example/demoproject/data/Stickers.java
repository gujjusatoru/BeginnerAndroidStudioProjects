package com.example.demoproject.data;

import com.example.demoproject.R;

public class Stickers {
    public static int[] id_obj={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};
    public static String[] name={
            "Sticker1",
            "Sticker2",
            "Sticker3",
            "Sticker4",
            "Sticker5",
            "Sticker6",
            "Sticker7",
            "Sticker8",
            "Sticker9",
            "Sticker10",
            "Sticker11",
            "Sticker12",
            "Sticker13",
            "Sticker14",
            "Sticker15",
            "Sticker16",
            "Sticker17",
            "Sticker18",
            "Sticker19",
            "Sticker20"
    };
    public static int[] drawable={
            R.drawable.c_1,
            R.drawable.c_2,
            R.drawable.c_3,
            R.drawable.c_4,
            R.drawable.c_5,
            R.drawable.c_6,
            R.drawable.c_7,
            R.drawable.c_8,
            R.drawable.c_9,
            R.drawable.c_10,
            R.drawable.c_11,
            R.drawable.c_12,
            R.drawable.c_13,
            R.drawable.c_14,
            R.drawable.c_15,
            R.drawable.c_16,
            R.drawable.c_17,
            R.drawable.c_18,
            R.drawable.c_19,
            R.drawable.c_20,
    };
}
