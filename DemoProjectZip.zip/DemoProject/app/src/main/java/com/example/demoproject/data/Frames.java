package com.example.demoproject.data;

import com.example.demoproject.R;

public class Frames {
    public static int[] id_obj={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
    public static String[] name={"Frame1",
            "Frame2",
            "Frame3",
            "Frame4",
            "Frame5",
            "Frame6",
            "Frame7",
            "Frame8",
            "Frame9",
            "Frame10",
            "Frame11",
            "Frame12",
            "Frame13",
            "Frame14",
            "Frame15"
    };
    public static int[] drawable={
            R.drawable.fff30,
            R.drawable.fff19,
            R.drawable.fff7,
            R.drawable.fff2,
            R.drawable.fff1,
            R.drawable.ff30,
            R.drawable.ff19,
            R.drawable.ff7,
            R.drawable.ff2,
            R.drawable.ff1,
            R.drawable.f30,
            R.drawable.f19,
            R.drawable.f7,
            R.drawable.f2,
            R.drawable.f1
    };
}
