package com.example.demoproject.canvas;

import static android.provider.MediaStore.Images.Media.getBitmap;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

import androidx.annotation.Nullable;

import com.example.demoproject.data.CanvasData;

import java.io.IOException;

public class DrawImage extends View {
    CanvasData savedData;
    private int strokeColor, fillColor;
    Bitmap image, frame, sticker;
    String text;
    float textSize;
    Paint fillPaint, strokePaint;
    private int imagewidth;
    private int imageheight;


    public DrawImage(Context context) throws IOException {
        super(context);
        init(null);
    }

    public DrawImage(Context context, @Nullable AttributeSet attrs) throws IOException {
        super(context, attrs);
        init(attrs);
    }

    public DrawImage(Context context, @Nullable AttributeSet attrs, int defStyleAttr) throws IOException {
        super(context, attrs, defStyleAttr);
        init(attrs);
    }

    public DrawImage(Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) throws IOException {
        super(context, attrs, defStyleAttr, defStyleRes);
        init(attrs);
    }
    public static float dpToPx(Context context, float dp) {
        return  (dp * context.getResources().getSystem().getDisplayMetrics().density);
    }
    public void getData(CanvasData savedData) throws IOException {
        this.savedData=savedData;
        Log.i("get Data", "text:"+savedData.getText());
        imageheight=(int)(savedData.getFrameHeight()*savedData.getScaleFactorY());
        imagewidth=(int)(savedData.getFrameWidth()*savedData.getScaleFactorX());
        init(null);
    }
    public void init(@Nullable AttributeSet set) throws IOException {
        if(savedData==null){
            return;
        }
        else{
        image=Bitmap.createScaledBitmap(getBitmap(getContext().getContentResolver(),savedData.getBitmapIMG()), imagewidth, imageheight, false);
        Log.i("Image", "bitmap: "+image);
        frame= Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getContext().getResources(),savedData.getFrameID()),savedData.getFrameWidth(),savedData.getFrameHeight(),false);
        Log.i("Frame", "bitmap: "+frame);
        sticker=Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getContext().getResources(),savedData.getStickerID()),(int)dpToPx(getContext(),100),(int)dpToPx(getContext(),100),false);
        Log.i("Sticker", "bitmap: "+sticker);
        text=savedData.getText();
        textSize=dpToPx(getContext(),32);
        strokeColor=savedData.getTextStrokeID();
        fillColor=savedData.getTextFillID();
        strokePaint=new Paint(Paint.ANTI_ALIAS_FLAG);
        strokePaint.setStyle(Paint.Style.STROKE);
        strokePaint.setStrokeWidth(2);
        strokePaint.setColor(getContext().getColor(strokeColor));
        strokePaint.setStrokeJoin(Paint.Join.ROUND);
        strokePaint.setTextSize(textSize);
        fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        fillPaint.setStyle(Paint.Style.FILL);
        fillPaint.setColor(getContext().getColor(fillColor));
        fillPaint.setTextSize(textSize);
        invalidate();}

    }

    @Override
    public void addOnLayoutChangeListener(OnLayoutChangeListener listener) {
        super.addOnLayoutChangeListener(listener);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if(savedData!=null){
        canvas.drawBitmap(image,savedData.getImageX()*savedData.getScaleFactorX(),savedData.getImageY()*savedData.getScaleFactorY(),null);
        canvas.drawBitmap(frame,0,0,null);
        canvas.drawBitmap(sticker,savedData.getStickerX(),savedData.getStickerY(),null);
        canvas.drawText(text,savedData.getTextX(),savedData.getTextY()+textSize,fillPaint);
        canvas.drawText(text,savedData.getTextX(),savedData.getTextY()+textSize,strokePaint);}
    }
}
